<script>
  function showSection(sectionId) {
    var sections = document.getElementsByClassName("section");
    for (var i = 0; i < sections.length; i++) {
      sections[i].style.display = "none";
    }
    document.getElementById(sectionId).style.display = "block";
  }

  function validatePassword() {
    var password = document.getElementById("password").value;
    if (password === "yourpassword") {
      showSection("one-time-password");
    } else {
      alert("Invalid password. Please try again.");
    }
  }

  function saveOTP() {
    var otp = document.getElementById("otp").value;
    alert("OTP saved: " + otp);
  }

  function captureFingerprint() {
    // Simulating capturing fingerprint by showing an alert message
    alert("Fingerprint captured.");
    // You can implement actual fingerprint capturing logic here
  }
</script>